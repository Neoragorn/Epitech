
#ifndef INT_H
# define INT_H

# include "object.h"

extern Class* Int;

#endif

