/*
** float.c for float in /home/casier_s/os-home/piscine_tek2/rush1/piscine_cpp_rush1/ex_04
** 
** Made by sofian casier
** Login   <casier_s@epitech.net>
** 
** Started on  Sat Jan 11 18:33:24 2014 sofian casier
** Last update Sat Jan 11 20:30:47 2014 quentin journet
*/

#include	<stdlib.h>
#include	<stdio.h>
#include	"new.h"
#include	"char.h"
#include	"bool.h"
#include	"raise.h"

typedef struct s_Char
{
  Class         base;
  char		i;
}               CharClass;

static void Char_dtor(Object* self)
{
  (void) self;
}

static void Char_ctor(CharClass* self, va_list *ap)
{
  self->i = va_arg(*ap, int);
}

static char* Char_to_String(CharClass *self)
{
  char *str;

  if ((str = malloc(sizeof(*str) * self->base.__size__)) == NULL)
    return (NULL);
  snprintf(str, self->base.__size__, "%d", self->i);
  return (str);
}

static Object   *Char_add(const Object* self, const Object* other)
{
  CharClass   *pClass;
  CharClass   *pClass2;
  Object        *retur;

  pClass = (CharClass*)self;
  pClass2 = (CharClass*)other;
  retur = new(Char, pClass->i + pClass2->i);
  return (retur);
}

static Object   *Char_sub(const Object* self, const Object* other)
{
  CharClass   *pClass;
  CharClass   *pClass2;
  Object        *retur;

  pClass = (CharClass*)self;
  pClass2 = (CharClass*)other;
  retur = new(Char, pClass->i - pClass2->i);
  return (retur);
}

static Object   *Char_mul(const Object* self, const Object* other)
{
  CharClass   *pClass;
  CharClass   *pClass2;
  Object        *retur;

  pClass = (CharClass*)self;
  pClass2 = (CharClass*)other;
  retur = new(Char, pClass->i * pClass2->i);
  return (retur);
}

static Object   *Char_div(const Object* self, const Object* other)
{
  CharClass   *pClass;
  CharClass   *pClass2;
  Object        *retur;

  pClass = (CharClass*)self;
  pClass2 = (CharClass*)other;
  if (pClass2->i == 0)
    raise("floating exception");
  retur = new(Char, pClass->i / pClass2->i);
  return (retur);
}

static bool   Char_eq(const Object* self, const Object* other)
{
  CharClass   *pClass;
  CharClass   *pClass2;

  pClass = (CharClass*)self;
  pClass2 = (CharClass*)other;
  if (pClass2->i != pClass->i)
    return (false);
  return (true);
}

static bool   Char_gt(const Object* self, const Object* other)
{
  CharClass   *pClass;
  CharClass   *pClass2;

  pClass = (CharClass*)self;
  pClass2 = (CharClass*)other;
  if (pClass->i > pClass2->i)
    return (true);
  return (false);
}

static bool   Char_lt(const Object* self, const Object* other)
{
  CharClass   *pClass;
  CharClass   *pClass2;

  pClass = (CharClass*)self;
  pClass2 = (CharClass*)other;
  if (pClass->i < pClass2->i)
    return (true);
  return (false);
}

static CharClass default_char = {
  {
    sizeof (CharClass),
    "Char",
    (ctor_t) &Char_ctor,
    (dtor_t) &Char_dtor,
    (to_string_t) &Char_to_String,
    (binary_operator_t) &Char_add,
    (binary_operator_t) &Char_sub,
    (binary_operator_t) &Char_mul,
    (binary_operator_t) &Char_div,
    (binary_comparator_t) &Char_eq,
    (binary_comparator_t) &Char_gt,
    (binary_comparator_t) &Char_lt},
  0
};

Class *Char = (Class *) &default_char;
