/*
** float.c for float in /home/casier_s/os-home/piscine_tek2/rush1/piscine_cpp_rush1/ex_04
** 
** Made by sofian casier
** Login   <casier_s@epitech.net>
** 
** Started on  Sat Jan 11 18:33:24 2014 sofian casier
** Last update Sat Jan 11 20:30:13 2014 quentin journet
*/

#include	<stdlib.h>
#include	<stdio.h>
#include	"new.h"
#include	"float.h"
#include	"bool.h"
#include	"raise.h"

typedef struct s_Float
{
  Class         base;
  float		i;
}               FloatClass;

static void Float_dtor(Object* self)
{
  (void) self;
}

static void Float_ctor(FloatClass* self, va_list *ap)
{
  self->i = va_arg(*ap, double);
}

static char* Float_to_String(FloatClass *self)
{
  char *str;

  if ((str = malloc(sizeof(*str) * self->base.__size__)) == NULL)
    return (NULL);
  snprintf(str, self->base.__size__, "%f", self->i);
  return (str);
}

static Object   *Float_add(const Object* self, const Object* other)
{
  FloatClass   *pClass;
  FloatClass   *pClass2;
  Object        *retur;

  pClass = (FloatClass*)self;
  pClass2 = (FloatClass*)other;
  retur = new(Float, pClass->i + pClass2->i);
  return (retur);
}

static Object   *Float_sub(const Object* self, const Object* other)
{
  FloatClass   *pClass;
  FloatClass   *pClass2;
  Object        *retur;

  pClass = (FloatClass*)self;
  pClass2 = (FloatClass*)other;
  retur = new(Float, pClass->i - pClass2->i);
  return (retur);
}

static Object   *Float_mul(const Object* self, const Object* other)
{
  FloatClass   *pClass;
  FloatClass   *pClass2;
  Object        *retur;

  pClass = (FloatClass*)self;
  pClass2 = (FloatClass*)other;
  retur = new(Float, pClass->i * pClass2->i);
  return (retur);
}

static Object   *Float_div(const Object* self, const Object* other)
{
  FloatClass   *pClass;
  FloatClass   *pClass2;
  Object        *retur;

  pClass = (FloatClass*)self;
  pClass2 = (FloatClass*)other;
  if (pClass2->i == 0)
    raise("floating exception");
  retur = new(Float, pClass->i / pClass2->i);
  return (retur);
}

static bool   Float_eq(const Object* self, const Object* other)
{
  FloatClass   *pClass;
  FloatClass   *pClass2;

  pClass = (FloatClass*)self;
  pClass2 = (FloatClass*)other;
  if (pClass2->i != pClass->i)
    return (false);
  return (true);
}

static bool   Float_gt(const Object* self, const Object* other)
{
  FloatClass   *pClass;
  FloatClass   *pClass2;

  pClass = (FloatClass*)self;
  pClass2 = (FloatClass*)other;
  if (pClass->i > pClass2->i)
    return (true);
  return (false);
}

static bool   Float_lt(const Object* self, const Object* other)
{
  FloatClass   *pClass;
  FloatClass   *pClass2;

  pClass = (FloatClass*)self;
  pClass2 = (FloatClass*)other;
  if (pClass->i < pClass2->i)
    return (true);
  return (false);
}

static FloatClass default_float = {
  {
    sizeof (FloatClass),
    "Float",
    (ctor_t) &Float_ctor,
    (dtor_t) &Float_dtor,
    (to_string_t) &Float_to_String,
    (binary_operator_t) &Float_add,
    (binary_operator_t) &Float_sub,
    (binary_operator_t) &Float_mul,
    (binary_operator_t) &Float_div,
    (binary_comparator_t) &Float_eq,
    (binary_comparator_t) &Float_gt,
    (binary_comparator_t) &Float_lt},
  0
};

Class *Float = (Class *) &default_float;
