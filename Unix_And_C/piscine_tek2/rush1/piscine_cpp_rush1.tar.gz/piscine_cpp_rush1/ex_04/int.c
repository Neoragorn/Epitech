/*
** float.c for float in /home/casier_s/os-home/piscine_tek2/rush1/piscine_cpp_rush1/ex_04
** 
** Made by sofian casier
** Login   <casier_s@epitech.net>
** 
** Started on  Sat Jan 11 18:33:24 2014 sofian casier
** Last update Sat Jan 11 20:29:48 2014 quentin journet
*/

#include	<stdlib.h>
#include	<stdio.h>
#include	"new.h"
#include	"int.h"
#include	"bool.h"
#include	"raise.h"

typedef struct s_Int
{
  Class         base;
  int		i;
}               IntClass;

static void Int_dtor(Object* self)
{
  (void) self;
}

static void Int_ctor(IntClass* self, va_list *ap)
{
  self->i = va_arg(*ap, int);
}

static char* Int_to_String(IntClass *self)
{
  char *str;

  if ((str = malloc(sizeof(*str) * self->base.__size__)) == NULL)
    return (NULL);
  snprintf(str, self->base.__size__, "%d", self->i);
  return (str);
}

static Object   *Int_add(const Object* self, const Object* other)
{
  IntClass   *pClass;
  IntClass   *pClass2;
  Object        *retur;

  pClass = (IntClass*)self;
  pClass2 = (IntClass*)other;
  retur = new(Int, pClass->i + pClass2->i);
  return (retur);
}

static Object   *Int_sub(const Object* self, const Object* other)
{
  IntClass   *pClass;
  IntClass   *pClass2;
  Object        *retur;

  pClass = (IntClass*)self;
  pClass2 = (IntClass*)other;
  retur = new(Int, pClass->i - pClass2->i);
  return (retur);
}

static Object   *Int_mul(const Object* self, const Object* other)
{
  IntClass   *pClass;
  IntClass   *pClass2;
  Object        *retur;

  pClass = (IntClass*)self;
  pClass2 = (IntClass*)other;
  retur = new(Int, pClass->i * pClass2->i);
  return (retur);
}

static Object   *Int_div(const Object* self, const Object* other)
{
  IntClass   *pClass;
  IntClass   *pClass2;
  Object        *retur;

  pClass = (IntClass*)self;
  pClass2 = (IntClass*)other;
  if (pClass2->i == 0)
    raise("floating exception");
  retur = new(Int, pClass->i / pClass2->i);
  return (retur);
}

static bool   Int_eq(const Object* self, const Object* other)
{
  IntClass   *pClass;
  IntClass   *pClass2;

  pClass = (IntClass*)self;
  pClass2 = (IntClass*)other;
  return (pClass->i == pClass2->i);
}

static bool   Int_gt(const Object* self, const Object* other)
{
  IntClass   *pClass;
  IntClass   *pClass2;

  pClass = (IntClass*)self;
  pClass2 = (IntClass*)other;
  return (pClass->i > pClass2->i);
}

static bool   Int_lt(const Object* self, const Object* other)
{
  IntClass   *pClass;
  IntClass   *pClass2;

  pClass = (IntClass*)self;
  pClass2 = (IntClass*)other;
  return (pClass->i < pClass2->i);
}

static IntClass default_int = {
  {
    sizeof (IntClass),
    "Int",
    (ctor_t) &Int_ctor,
    (dtor_t) &Int_dtor,
    (to_string_t) &Int_to_String,
    (binary_operator_t) &Int_add,
    (binary_operator_t) &Int_sub,
    (binary_operator_t) &Int_mul,
    (binary_operator_t) &Int_div,
    (binary_comparator_t) &Int_eq,
    (binary_comparator_t) &Int_gt,
    (binary_comparator_t) &Int_lt},
  0
};

Class *Int = (Class *) &default_int;
