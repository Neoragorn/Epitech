/*
** vertex.c for vert in /home/casier_s/os-home/piscine_tek2/rush1/piscine_cpp_rush1/ex_02
** 
** Made by sofian casier
** Login   <casier_s@epitech.net>
** 
** Started on  Sat Jan 11 15:07:41 2014 sofian casier
** Last update Sat Jan 11 18:25:28 2014 sofian casier
*/

#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	"vertex.h"

typedef struct s_Vertex
{
  Class		base;
  int		x, y, z;
}		VertexClass;

static void Vertex_dtor(Object* self)
{
  (void) self;
}

static void Vertex_ctor(VertexClass* self, va_list *ap)
{
  self->x = va_arg(*ap, int);
  self->y = va_arg(*ap, int);
  self->z = va_arg(*ap, int);
}

static char* Vertex_to_String(VertexClass *self)
{
  char *str;

  if ((str = malloc(sizeof(*str) * self->base.__size__)) == NULL)
    return (NULL);
  snprintf(str, self->base.__size__, "%s <(%i, %i, %i)>", self->base.__name__, self->x, self->y, self->z);
  return (str);
}

static VertexClass default_vertex = {
  { sizeof(VertexClass),
    "Point", 
    (ctor_t) &Vertex_ctor,
    (dtor_t) &Vertex_dtor,
    (to_string_t) &Vertex_to_String},
  0,
  0, 
  0
};

Class* Vertex = (Class*) &default_vertex;
