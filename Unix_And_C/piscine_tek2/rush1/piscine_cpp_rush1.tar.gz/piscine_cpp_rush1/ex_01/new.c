/*
** new.c for new in /home/journe_q//TEK2/piscine_cpp_rush1
** 
** Made by quentin journet
** Login   <journe_q@epitech.net>
** 
** Started on  Sat Jan 11 11:32:43 2014 quentin journet
** Last update Sat Jan 11 16:10:37 2014 sofian casier
*/

#include	<string.h>
#include	"stdlib.h"
#include	"new.h"
#include	"raise.h"

void		*new(Class *class)
{
  Object	*ob;

  if ((ob = malloc(class->__size__)) == NULL)
    raise("out of memory");
  memcpy(ob, class, class->__size__);
  if (class->__init__)
    class->__init__(ob);
  return (ob);
}

void		delete(Object *ptr)
{
  Class		*class;

  if (ptr)
    {
      class = ptr;
      if (class->__del__)
	class->__del__(ptr);
      free(ptr);
    }
}
