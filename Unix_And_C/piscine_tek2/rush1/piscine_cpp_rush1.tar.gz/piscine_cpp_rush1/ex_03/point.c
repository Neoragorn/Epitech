/*
** point.c for point in /home/casier_s/os-home/piscine_tek2/rush1/piscine_cpp_rush1/ex_02
** 
** Made by sofian casier
** Login   <casier_s@epitech.net>
** 
** Started on  Sat Jan 11 15:08:55 2014 sofian casier
** Last update Sat Jan 11 18:26:36 2014 sofian casier
*/

#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<stdarg.h>
#include	"point.h"
#include	"new.h"

typedef struct	point_class
{
    Class	base;
    int		x, y;
}		PointClass;

static void Point_dtor(Object* self)
{
  (void) self;
}

static void	Point_ctor(PointClass* self, va_list *ap)
{
  self->x = va_arg(*ap, int);
  self->y = va_arg(*ap, int);
}

static char	*Point_to_String(PointClass *self)
{
  char		*str;

  if ((str = malloc(sizeof(*str) * self->base.__size__)) == NULL)
    return (NULL);
  snprintf(str, self->base.__size__, "%s <(%i, %i)>", self->base.__name__, self->x, self->y);
  return (str);
}

static Object	*Point_add(Object* self, Object* other)
{
  PointClass	*pClass;
  PointClass	*pClass2;
  Object	*retur;

  pClass = (PointClass*)self;
  pClass2 = (PointClass*)other;
  retur = new(Point, pClass->x + pClass2->x, pClass->y + pClass2->y);
  return (retur);
}

static Object	*Point_sub(Object* self, Object* other)
{
  PointClass	*pClass;
  PointClass	*pClass2;
  Object	*retur;

  pClass = (PointClass*)self;
  pClass2 = (PointClass*)other;
  retur = new(Point, pClass->x - pClass2->x, pClass->y - pClass2->y);
  return (retur);

}

static PointClass default_point = {
  {sizeof(PointClass),
   "Point",
   (ctor_t)&Point_ctor,
   (dtor_t)&Point_dtor,
   (to_string_t)&Point_to_String,
   (binary_operator_t)&Point_add,
   (binary_operator_t)&Point_sub},
  0,
  0,
};

Class* Point = (Class*) &default_point;
