/*
** new.c for new in /home/journe_q//TEK2/piscine_cpp_rush1
** 
** Made by quentin journet
** Login   <journe_q@epitech.net>
** 
** Started on  Sat Jan 11 11:32:43 2014 quentin journet
** Last update Sat Jan 11 16:55:05 2014 quentin journet
*/

#include	<string.h>
#include	"stdlib.h"
#include	"new.h"
#include	"raise.h"

Object		*va_new(Class *class, va_list *ap)
{
  Class		*check;
  void		*copy_class;
  static Class	default_class = {sizeof(Class), "default", NULL, NULL, NULL, NULL, NULL};

  copy_class = malloc(class->__size__);
  if (copy_class == NULL)
    raise("out of memory");
  check = (Class *) copy_class;

  if (check == NULL)
    check = &default_class;
  check = memcpy(check, class, class->__size__);
  if (check->__init__)
    check->__init__(check, ap);
  return (check);
}

Object		*new(Class *class, ...)
{
  Object	*ob;
  va_list	ap;

  va_start(ap, class);
  ob = va_new(class, &ap);
  va_end(ap);
  return (ob);
}

void		delete(Object *ptr)
{
  Class		*class;

  if (ptr)
    {
      class = ptr;
      if (class->__del__)
	class->__del__(ptr);
      free(ptr);
    }
}
