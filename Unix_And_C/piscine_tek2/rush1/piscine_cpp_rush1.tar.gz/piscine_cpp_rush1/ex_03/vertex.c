/*
** vertex.c for vert in /home/casier_s/os-home/piscine_tek2/rush1/piscine_cpp_rush1/ex_02
** 
** Made by sofian casier
** Login   <casier_s@epitech.net>
** 
** Started on  Sat Jan 11 15:07:41 2014 sofian casier
** Last update Sat Jan 11 18:27:02 2014 sofian casier
*/

#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<stdarg.h>
#include	"vertex.h"
#include	"new.h"

typedef struct s_Vertex
{
  Class		base;
  int		x, y, z;
}		VertexClass;

static void Vertex_dtor(Object* self)
{
  (void) self;
}

static void Vertex_ctor(VertexClass* self, va_list *ap)
{
  self->x = va_arg(*ap, int);
  self->y = va_arg(*ap, int);
  self->z = va_arg(*ap, int);
}

static char* Vertex_to_String(VertexClass *self)
{
  char *str;

  if ((str = malloc(sizeof(*str) * self->base.__size__)) == NULL)
    return (NULL);
  snprintf(str, self->base.__size__, "%s <(%i, %i, %i)>", self->base.__name__, self->x, self->y, self->z);
  return (str);
}

static Object	*Vertex_add(const Object* self, const Object* other)
{
  VertexClass	*pClass;
  VertexClass	*pClass2;
  Object	*retur;

  pClass = (VertexClass*)self;
  pClass2 = (VertexClass*)other;
  retur = new(Vertex, pClass->x + pClass2->x, pClass->y + pClass2->y, pClass->z + pClass2->z);
  return (retur);
}

static Object	*Vertex_sub(const Object* self, const Object* other)
{
  VertexClass	*pClass;
  VertexClass	*pClass2;
  Object	*retur;

  pClass = (VertexClass*)self;
  pClass2 = (VertexClass*)other;
  retur = new(Vertex, pClass->x - pClass2->x, pClass->y - pClass2->y, pClass->z - pClass2->z);
  return (retur);
}

static VertexClass default_vertex = {
  { 
    sizeof(VertexClass), 
    "Point", 
    (ctor_t) &Vertex_ctor,
    (dtor_t) &Vertex_dtor,
    (to_string_t) &Vertex_to_String,
    (binary_operator_t) &Vertex_add,
    (binary_operator_t) &Vertex_sub},
  0,
  0,
  0
};

Class* Vertex = (Class*) &default_vertex;
